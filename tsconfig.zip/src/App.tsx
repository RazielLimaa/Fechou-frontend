import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";
import NotFound from "./pages/not-found";
import Home from "./pages/home";
import Vision from "./pages/vision";
import System from "./pages/system";
import Login from "./pages/login";
import Register from "./pages/register";
import NovaProposta from "./pages/nova-proposta";
import Templates from "./pages/templates";
import Propostas from "./pages/propostas";
import pagepayment from "./pages/checkout";
import ContratoPublico from "./pages/contrato-publico";
import PlanCheckout from "./pages/plan-checkout";
import PremiumDashboard from "./pages/premium-dashboard";
import ContratoView from "./pages/contrato-view";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home}/>
      <Route path="/vision" component={Vision}/>
      <Route path="/system" component={System}/>
      <Route path="/login" component={Login}/>
      <Route path="/register" component={Register}/>
      <Route path="/propostas" component={Propostas}/>
      <Route path="/propostas/nova" component={NovaProposta}/>
      <Route path="/templates" component={Templates}/>
      <Route path="/contrato/:id" component={ContratoView}/>
      <Route path="/c/:token" component={ContratoPublico}/>
      <Route path="/checkout" component={pagepayment}/>
      <Route path="/checkout/plano/:id" component={PlanCheckout} />
      <Route path="/dashboard/premium" component={PremiumDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
