import { api } from './api';

export interface MercadoPagoStatusResponse {
  connected: boolean;
  authMethod: 'oauth' | 'api_key' | null;
  mpUserId: string | null;
  expiresAt: string | null;
}

export interface VerifyApiKeyRequest {
  accessToken: string;
}

export interface VerifyApiKeyResponse {
  valid: boolean;
  message?: string;
}

export interface RegisterApiKeyRequest {
  accessToken: string;
}

export const mercadoPagoService = {
  getStatus: async () => {
    const { data } = await api.get<MercadoPagoStatusResponse>('/api/mercadopago/status');
    return data;
  },
  connectOAuth: () => {
    window.location.href = `${api.defaults.baseURL}/api/mercadopago/connect`;
  },
  verifyApiKey: async (payload: VerifyApiKeyRequest) => {
    const { data } = await api.post<VerifyApiKeyResponse>('/api/mercadopago/api-key/verify', payload);
    return data;
  },
  registerApiKey: async (payload: RegisterApiKeyRequest) => {
    const { data } = await api.post('/api/mercadopago/api-key/register', payload);
    return data;
  },
};
