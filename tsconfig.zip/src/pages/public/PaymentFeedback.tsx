import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Card } from '../../components/ui/card';
import { CheckCircle, XCircle, Clock } from 'lucide-react';

export const PaymentFeedbackPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const status = searchParams.get('status');

  const config: {
    icon: React.ReactNode;
    title: string;
    message: string;
    color: string;
  } = (({
    success: {
      icon: <CheckCircle className="w-16 h-16 text-green-500" />,
      title: 'Pagamento Confirmado!',
      message: 'Sua transação foi processada com sucesso. O freelancer foi notificado.',
      color: 'bg-green-50 text-green-700',
    },
    failure: {
      icon: <XCircle className="w-16 h-16 text-red-500" />,
      title: 'Ops! Algo deu errado.',
      message: 'Não foi possível processar seu pagamento. Por favor, tente novamente.',
      color: 'bg-red-50 text-red-700',
    },
    pending: {
      icon: <Clock className="w-16 h-16 text-yellow-500" />,
      title: 'Pagamento em Processamento',
      message: 'Seu pagamento está sendo analisado. Avisaremos assim que for confirmado.',
      color: 'bg-yellow-50 text-yellow-700',
    },
  } as any)[status || 'pending'] || {
    icon: <Clock className="w-16 h-16 text-yellow-500" />,
    title: 'Pagamento em Processamento',
    message: 'Seu pagamento está sendo analisado. Avisaremos assim que for confirmado.',
    color: 'bg-yellow-50 text-yellow-700',
  });

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full text-center p-8">
        <div className="flex justify-center mb-6">{config.icon}</div>
        <h1 className="text-2xl font-bold mb-4">{config.title}</h1>
        <div className={`p-4 rounded-lg mb-6 ${config.color}`}>
          {config.message}
        </div>
        <Link to="/" className="text-blue-600 hover:underline">
          Voltar para o site
        </Link>
      </Card>
    </div>
  );
};
