import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { proposalsService } from '../../services/proposals';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/Button';
import { LoadingState } from '../../components/ui/LoadingState';
import { Alert } from '../../components/ui/Alert';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const signSchema = z.object({
  signerName: z.string().min(3, 'Nome muito curto'),
  signerDocument: z.string().min(11, 'Documento inválido'),
});

type SignForm = z.infer<typeof signSchema>;

export const PublicContractPage: React.FC = () => {
  const { token } = useParams<{ token: string }>();

  const { data: proposal, isLoading, error, refetch } = useQuery({
    queryKey: ['public-proposal', token],
    queryFn: () => proposalsService.getPublic(token!),
    enabled: !!token,
  });

  const signMutation = useMutation({
    mutationFn: (data: SignForm) => proposalsService.signContract(token!, data),
    onSuccess: () => refetch(),
  });

  const checkoutMutation = useMutation({
    mutationFn: () => proposalsService.checkout(token!, {
      successUrl: `${window.location.origin}/p/success`,
      failureUrl: `${window.location.origin}/p/failure`,
      pendingUrl: `${window.location.origin}/p/pending`,
    }),
    onSuccess: (data) => {
      window.location.href = data.checkoutUrl;
    },
  });

  const { register, handleSubmit, formState: { errors } } = useForm<SignForm>({
    resolver: zodResolver(signSchema),
  });

  if (isLoading) return <LoadingState />;
  if (error) return <Alert variant="error" message="Contrato não encontrado ou expirado" />;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-6">
        <header className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Assinatura de Contrato</h1>
          <p className="text-gray-600 mt-2">{proposal?.title}</p>
        </header>

        <Card>
          <div className="space-y-6">
            <div className="prose max-w-none p-4 bg-white border rounded h-64 overflow-y-auto">
              <h2 className="text-lg font-bold">Proposta de Prestação de Serviços</h2>
              <p>Freelancer: {proposal?.freelancerName}</p>
              <p>Valor: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(proposal?.amount || 0)}</p>
              <div className="mt-4 text-gray-700">
                {proposal?.description}
              </div>
            </div>

            {!proposal?.isSigned ? (
              <form onSubmit={handleSubmit((data) => signMutation.mutate(data))} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Seu Nome Completo</label>
                    <input
                      {...register('signerName')}
                      className="mt-1 block w-full border rounded-md p-2"
                      placeholder="Nome Sobrenome"
                    />
                    {errors.signerName && <p className="text-red-500 text-xs mt-1">{errors.signerName.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">CPF/CNPJ</label>
                    <input
                      {...register('signerDocument')}
                      className="mt-1 block w-full border rounded-md p-2"
                      placeholder="000.000.000-00"
                    />
                    {errors.signerDocument && <p className="text-red-500 text-xs mt-1">{errors.signerDocument.message}</p>}
                  </div>
                </div>
                <Button type="submit" className="w-full" isLoading={signMutation.isPending}>
                  Assinar Contrato
                </Button>
              </form>
            ) : (
              <div className="space-y-4">
                <Alert variant="success" message="Contrato assinado com sucesso!" />
                {!proposal.isPaid ? (
                  <Button 
                    className="w-full h-12 text-lg" 
                    onClick={() => checkoutMutation.mutate()}
                    isLoading={checkoutMutation.isPending}
                  >
                    Ir para Pagamento
                  </Button>
                ) : (
                  <Alert variant="info" message="Este contrato já foi pago." />
                )}
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};
