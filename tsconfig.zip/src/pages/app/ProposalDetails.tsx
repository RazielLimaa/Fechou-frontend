import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { proposalsService } from '../../services/proposals';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { LoadingState } from '../../components/ui/LoadingState';
import { Alert } from '../../components/ui/Alert';
import { CopyField } from '../../components/ui/CopyField';

export const ProposalDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  
  const { data: proposal, isLoading, error } = useQuery({
    queryKey: ['proposal', id],
    queryFn: () => proposalsService.getById(id!),
    enabled: !!id,
  });

  const shareMutation = useMutation({
    mutationFn: () => proposalsService.generateShareLink(id!),
  });

  const paymentMutation = useMutation({
    mutationFn: () => proposalsService.generatePaymentLink(id!),
  });

  if (isLoading) return <LoadingState />;
  if (error || !proposal) return <Alert variant="error" message="Proposta não encontrada" />;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <header className="flex items-center gap-4">
        <Link to="/app/proposals" className="text-blue-600 hover:underline">← Voltar</Link>
        <h1 className="text-2xl font-bold">Proposta: {proposal.title}</h1>
      </header>

      <div className="grid md:grid-cols-2 gap-6">
        <Card title="Detalhes">
          <div className="space-y-4">
            <div className="flex justify-between border-b pb-2">
              <span className="text-gray-600">Valor</span>
              <span className="font-semibold">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(proposal.amount)}</span>
            </div>
            <div className="flex justify-between border-b pb-2">
              <span className="text-gray-600">Status</span>
              <span className="capitalize font-medium">{proposal.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Criada em</span>
              <span>{new Date(proposal.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </Card>

        <Card title="Links de Acesso">
          <div className="space-y-6">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Link do Contrato Público</h4>
              <Button 
                onClick={() => shareMutation.mutate()} 
                className="w-full"
                isLoading={shareMutation.isPending}
              >
                Gerar Link do Contrato
              </Button>
              {shareMutation.data && <CopyField value={shareMutation.data.shareLink} />}
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium">Link de Pagamento Direto</h4>
              <Button 
                onClick={() => paymentMutation.mutate()} 
                variant="outline"
                className="w-full"
                isLoading={paymentMutation.isPending}
              >
                Gerar Link de Pagamento
              </Button>
              {paymentMutation.data && <CopyField value={paymentMutation.data.paymentUrl} />}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
