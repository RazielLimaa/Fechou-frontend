import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { proposalsService } from '../../services/proposals';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { LoadingState } from '../../components/ui/LoadingState';
import { Alert } from '../../components/ui/Alert';
import { Link } from 'react-router-dom';

export const ProposalsListPage: React.FC = () => {
  const { data: proposals, isLoading, error } = useQuery({
    queryKey: ['proposals'],
    queryFn: proposalsService.list,
  });

  const shareMutation = useMutation({
    mutationFn: (id: string) => proposalsService.generateShareLink(id),
    onSuccess: (data) => {
      navigator.clipboard.writeText(data.shareLink);
      alert('Link do contrato copiado para a área de transferência!');
    },
  });

  if (isLoading) return <LoadingState />;
  if (error) return <Alert variant="error" message="Erro ao carregar propostas" />;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <header className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Minhas Propostas</h1>
      </header>

      <div className="grid gap-4">
        {proposals?.length === 0 ? (
          <p className="text-center text-gray-500 py-10">Nenhuma proposta encontrada.</p>
        ) : (
          proposals?.map((proposal) => (
            <Card key={proposal.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 gap-4">
              <div>
                <h3 className="font-semibold text-lg">{proposal.title}</h3>
                <p className="text-sm text-gray-600">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(proposal.amount)}
                </p>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  proposal.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {proposal.status}
                </span>
              </div>
              <div className="flex gap-2">
                <Link to={`/app/proposals/${proposal.id}`}>
                  <Button variant="outline">Ver proposta</Button>
                </Link>
                <Button 
                  onClick={() => shareMutation.mutate(proposal.id)}
                  isLoading={shareMutation.isPending}
                >
                  Gerar link do contrato
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
