import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { mercadoPagoService } from '../../services/mercadoPago';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/card';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Alert } from '../../components/ui/Alert';
import { LoadingState } from '../../components/ui/LoadingState';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const apiKeySchema = z.object({
  accessToken: z.string().min(1, 'A chave é obrigatória'),
});

type ApiKeyForm = z.infer<typeof apiKeySchema>;

export const PaymentSettingsPage: React.FC = () => {
  const queryClient = useQueryClient();
  const { data: status, isLoading, error } = useQuery({
    queryKey: ['mp-status'],
    queryFn: mercadoPagoService.getStatus,
  });

  const verifyMutation = useMutation({
    mutationFn: (data: ApiKeyForm) => mercadoPagoService.verifyApiKey(data),
  });

  const registerMutation = useMutation({
    mutationFn: (data: ApiKeyForm) => mercadoPagoService.registerApiKey(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mp-status'] });
    },
  });

  const { register, handleSubmit, formState: { errors }, watch } = useForm<ApiKeyForm>({
    resolver: zodResolver(apiKeySchema),
  });

  const accessToken = watch('accessToken');

  if (isLoading) return <LoadingState />;
  if (error) return <Alert variant="error" message="Erro ao carregar status do Mercado Pago" />;

  return (
    <div className="container mx-auto p-6 space-y-8">
      <header>
        <h1 className="text-2xl font-bold">Configurações de Pagamento</h1>
        <p className="text-gray-600">Conecte sua conta do Mercado Pago para receber pagamentos.</p>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <Card title="Status da Conexão">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Status:</span>
              <StatusBadge status={status?.connected ? 'connected' : 'disconnected'} method={status?.authMethod} />
            </div>
            {status?.mpUserId && (
              <div className="flex items-center justify-between text-sm">
                <span>ID Usuário MP:</span>
                <span className="font-mono">{status.mpUserId}</span>
              </div>
            )}
            {status?.expiresAt && (
              <div className="flex items-center justify-between text-sm">
                <span>Expira em:</span>
                <span>{new Date(status.expiresAt).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        </Card>

        <Card title="Conectar Mercado Pago (OAuth)">
          <div className="space-y-4">
            <p className="text-sm text-gray-600">Recomendado. Conexão segura via Mercado Pago.</p>
            <Button onClick={() => mercadoPagoService.connectOAuth()} className="w-full">
              Conectar com Mercado Pago
            </Button>
          </div>
        </Card>

        <Card title="Conectar por Chave API">
          <form onSubmit={handleSubmit((data) => registerMutation.mutate(data))} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Access Token</label>
              <input
                type="password"
                {...register('accessToken')}
                className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
                placeholder="APP_USR-..."
              />
              {errors.accessToken && <p className="text-red-500 text-xs mt-1">{errors.accessToken.message}</p>}
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => verifyMutation.mutate({ accessToken })}
                isLoading={verifyMutation.isPending}
              >
                Verificar Chave
              </Button>
              <Button
                type="submit"
                className="flex-1"
                isLoading={registerMutation.isPending}
              >
                Salvar Chave
              </Button>
            </div>
            {verifyMutation.data && (
              <Alert
                variant={verifyMutation.data.valid ? 'success' : 'error'}
                message={verifyMutation.data.valid ? 'Chave válida!' : verifyMutation.data.message || 'Chave inválida'}
              />
            )}
          </form>
        </Card>
      </section>
    </div>
  );
};
