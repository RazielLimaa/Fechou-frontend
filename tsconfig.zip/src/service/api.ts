export const API_URL = (import.meta.env.VITE_API_URL as string | undefined)?.trim();

type JsonValue =
  | string
  | number
  | boolean
  | null
  | { [key: string]: JsonValue }
  | JsonValue[];

type JsonBody = JsonValue;

function joinUrl(base: string, path: string) {
  const b = base.endsWith("/") ? base.slice(0, -1) : base;
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${b}${p}`;
}

export async function apiFetch<T>(
  path: string,
  options: RequestInit & { json?: JsonBody; token?: string } = {},
): Promise<T> {
  if (!API_URL) {
    throw new Error("VITE_API_URL não está definido. Configure no .env e reinicie o dev server.");
  }

  const { json, token, headers, ...rest } = options;

  const res = await fetch(joinUrl(API_URL, path), {
    ...rest,
    headers: {
      Accept: "application/json",
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(headers ?? {}),
    },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });

  if (res.status === 204 || res.status === 205) {
    return undefined as T;
  }

  const contentType = res.headers.get("content-type") ?? "";
  const isJson = contentType.includes("application/json");

  const data = isJson
    ? await res.json().catch(() => null)
    : await res.text().catch(() => null);

  if (!res.ok) {
    const message =
      (data &&
        typeof data === "object" &&
        "message" in data &&
        typeof (data as any).message === "string" &&
        (data as any).message.trim().length > 0 &&
        (data as any).message) ||
      (typeof data === "string" && data.trim().length > 0 ? data : `Erro HTTP ${res.status}`);

    throw new Error(message);
  }

  return data as T;
}

export const mpService = {
  getStatus: () => apiFetch<{ connected: boolean; expiresAt?: string }>("/api/mercadopago/status"),
  connect: () => {
    const API_URL = (import.meta.env.VITE_API_URL as string || "").trim();
    window.location.href = `${API_URL}/api/mercadopago/connect`;
  },
  generatePaymentLink: (proposalId: number) => 
    apiFetch<{ paymentUrl: string }>(`/api/proposals/${proposalId}/payment-link`, { method: "POST" }),
};
