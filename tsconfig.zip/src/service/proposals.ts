export type ApiProposalStatus = "pendente" | "vendida" | "cancelada";

export interface ApiProposal {
  id: number;
  userId: number;
  title: string;
  clientName: string;
  description: string;
  value: string; // 
  status: ApiProposalStatus;
  createdAt: string;
  contract?: {
    signed: boolean;
    signedAt: string | null;
    signerName: string | null;
    canPay: boolean;
  };
}

const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

function getToken() {
  return localStorage.getItem("access_token") ?? "";
}

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
      ...(init?.headers ?? {}),
    },
  });

  const text = await res.text();
  const data = text ? JSON.parse(text) : null;

  if (!res.ok) {
    throw new Error(data?.message ?? `Erro ${res.status}`);
  }

  return data as T;
}

export function listProposals(): Promise<ApiProposal[]> {
  return apiFetch<ApiProposal[]>("/api/proposals");
}

export function createProposal(input: {
  title: string;
  clientName: string;
  description: string;
  value: number;
}): Promise<ApiProposal> {
  return apiFetch<ApiProposal>("/api/proposals", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export function generateShareLink(id: number, expiresInHours?: number): Promise<{ shareToken: string; expiresAt: string; path: string }> {
  return apiFetch<{ shareToken: string; expiresAt: string; path: string }>(`/api/proposals/${id}/share-link`, {
    method: "POST",
    body: JSON.stringify({ expiresInHours }),
  });
}

export function getPublicProposal(token: string): Promise<ApiProposal> {
  return apiFetch<ApiProposal>(`/api/proposals/public/${token}`);
}

export function signProposal(token: string, data: { signerName: string; signerDocument: string }): Promise<{ message: string }> {
  return apiFetch<{ message: string }>(`/api/proposals/public/${token}/sign`, {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export function createCheckout(token: string, data: { successUrl: string; failureUrl: string; pendingUrl: string; payerEmail?: string }): Promise<{ checkoutUrl: string; preferenceId: string }> {
  return apiFetch<{ checkoutUrl: string; preferenceId: string }>(`/api/payments/public/${token}/checkout`, {
    method: "POST",
    body: JSON.stringify(data),
  });
}

export function createSubscriptionCheckout(data: { priceId: string; successUrl: string; cancelUrl: string }) {
  return apiFetch<{ checkoutUrl: string; sessionId: string }>("/api/subscriptions/checkout", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Idempotency-Key": `sub-checkout-${Date.now()}`
    }
  });
}
