import React from 'react';
import { cn } from '../../lib/utils';

interface StatusBadgeProps {
  status: 'connected' | 'disconnected';
  method?: 'oauth' | 'api_key' | null;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, method }) => {
  if (status === 'disconnected') {
    return (
      <span className="px-2 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-800">
        Não conectada
      </span>
    );
  }

  const label = method === 'oauth' ? 'Conta MP conectada (OAuth)' : 'Conta MP conectada (API Key)';
  
  return (
    <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
      {label}
    </span>
  );
};
