import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { Button } from './Button';

export const CopyField: React.FC<{ value: string }> = ({ value }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex gap-2">
      <input
        type="text"
        readOnly
        value={value}
        className="flex-1 bg-gray-50 border rounded-md p-2 text-sm font-mono text-gray-600 truncate"
      />
      <Button variant="outline" size="sm" onClick={handleCopy}>
        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
      </Button>
    </div>
  );
};
