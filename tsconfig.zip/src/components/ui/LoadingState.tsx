import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingState: React.FC = () => (
  <div className="flex flex-col items-center justify-center p-12 space-y-4">
    <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    <p className="text-gray-500 animate-pulse">Carregando...</p>
  </div>
);
